<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/all.min.css" />
		  <!-- Insert these scripts at the bottom of the HTML, but before you use any Firebase services -->

		<title>Thời khóa biểu</title>
	</head>
	<body>
		<div class="container">
			<?php include "navbar.php"; ?>
			
			<div class="card mt-3">
				<h5 class="card-header">Thời khóa biểu</h5>
				<div class="card-body">
				<a href="thoikhoabieu_them.php" class="btn btn-success mb-2"><i class="fal fa-plus"></i> Thêm mới</a>
				<table class="table table-bordered table-hover table-sm mb-0">
						<thead>
							<tr>
								<th width="5%">#</th>
								<th width="20%">Mã GV</th>
								<th width="65%">Mã học phần</th>
								<th width="5%">Học kỳ</th>
								<th width="10%">Năm học</th>
								<th width="5%">Nhóm</th>
							</tr>
						</thead>
						<tbody id="HienThi">
							
						</tbody>
					</table>
					<p class="card-text">Trang chủ hệ thống quản lý điểm danh sinh viên.</p>
				</div>
			</div>
			
			<?php include "footer.php"; ?>
		</div>
		
		<?php include "javascript.php"; ?>
		
		<script>
			const  user = db.collection("thoikhoabieu").doc("O6RPcUr8bNcHvIp1cmSU").get();
			db.collection("thoikhoabieu").doc("O6RPcUr8bNcHvIp1cmSU").get().then((querySnapshot) => {
				const schedual = querySnapshot.data()
				var stt = 1;
				var output= "";
				// console.log(querySnapshot.ref())
				// var mgv= db.ref('giangvien/'+ documentid);
				// console.log('data', documentid);
				// mgv.on('value', (snapshot) => {
				// 	const data = snapshot.val();
				// 	console.log('data', data);
				// 	// updateStarCount(postElement, data);
				// });

			// querySnapshot.forEach((doc) => {
			// //console.log(`${doc.id} => ${doc.data()}`);
			
				output += '<tr>';
					output += '<th>'+stt+'</th>';
					output += '<td>'+doc.data().mgv+'</td>';				
					output += '<td>'+doc.data().mhp+'</td>';
					output += '<td>'+doc.data().hocky+'</td>';
					output += '<td>'+doc.data().namhoc+'</td>';
					output += '<td>'+doc.data().nhom+'</td>';
					//output += '<td class="text-center"><a href="giangvien_sua.php?id='+doc.id+'"><i class="fal fa-edit"></i></a></td>';
					//output += '<td class="text-center"><a onclick="return confirm(\'Bạn có muốn xóa giảng viên '+ doc.data().hoten+' không?\')"  href="giangvien_xoa.php?id='+doc.id+'"><i class="fal fa-trash-alt"></i></a></td>';
				output += '</tr>';
			
			// 	stt++;
			// });
			
			$('#HienThi').html(output);
			console.log(output);
			});
		</script>
	</body>
</html>